<?php

$visitor_message = '<html xmlns="http://www.w3.org/1999/xhtml">

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title>Synotec Email</title>

    </head>



    <body>

        <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#f6f8fb"> 
            <tbody>
                <tr> 
                    <td style="padding-top:10px;padding-bottom:30px;padding-left:16px;padding-right:16px" align="center"> 
                        <table style="width:602px" width="602" cellspacing="0" cellpadding="0" border="0" align="center"> 
                            <tbody>

                                <tr> 
                                    <td bgcolor=""> 
                                        <table width="642" cellspacing="0" cellpadding="0" border="0"> 
                                            <tbody> 

                                                <tr> 
                                                    <td style="border:1px solid #dcdee3;padding:20px;background-color:#fff;width:600px" width="600px" bgcolor="#ffffff" align="center"> 
                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0"> 
                                                            <tbody>
                                                                <tr><td>
                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">

                                                                            <tbody><tr>




                                                                                    <td width="393">

                                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-bottom: 25px;">

                                                                                            <tbody><tr>

                                                                                                    <td valign="middle" height="46" align="right">

                                                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">

                                                                                                            <tbody><tr>

                                                                                                                    <td width="67%" align="right">

                                                                                                                        <font style="font-family:Verdana,Geneva,sans-serif;color:#68696a;font-size:18px">

                                                                                                                            <a href="' . $site_link . '" style="color:#68696a;text-decoration:none;" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.gallecabsandtours.com&amp;source=gmail&amp;ust=1574393192616000&amp;usg=AFQjCNGNM8_Z7ZMe7ndwFlJuHEP29nDd3Q">

                                                                                                                                <h4>' . $website_name . '</h4>

                                                                                                                            </a>

                                                                                                                        </font>

                                                                                                                    </td>

                                                                                                                    <td width="4%">&nbsp;</td>

                                                                                                                </tr>

                                                                                                            </tbody></table>

                                                                                                    </td>

                                                                                                </tr>


                                                                                            </tbody></table>

                                                                                    </td>

                                                                                </tr>

                                                                            </tbody></table>
                                                                    </td>
                                                                </tr><tr> 
                                                                    <td style="font-size:20px;color:#33468f;line-height:28px;font-family:Arial,Helvetica,sans-serif;padding-bottom:20px;padding-top: 0px;font-weight: 600;" align="left"> Thank You ! </td> 
                                                                </tr>
                                                            </tbody> 
                                                        </table> 

                                                        <table style="background-color:#f5f7fa" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F5F7FA"> 

                                                            <tbody> 
                                                                <tr> 
                                                                    <td style="font-size:14px;color:#333;line-height:18px;font-family:Arial,Helvetica,sans-serif;padding:15px 20px 10px;font-weight: 600;" align="left"> Hi , ' . $visitor_name . ' </td> 
                                                                </tr> 
                                                            </tbody> 
                                                        </table> 
                                                        <table style="background-color:#f5f7fa" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F5F7FA"> 
                                                            <tbody> 
                                                                <tr> 
                                                                    <td style="word-wrap:break-word;font-size:14px;color:#333;line-height:18px;font-family:Arial,Helvetica,sans-serif;padding:10px 20px" align="left"> <p> ' . $customer_msg. ' </p></td> 
                                                                </tr> 
                                                                <tr> 
                                                                    <td style="word-wrap:break-word;font-size:14px;color:#333;line-height:10px;font-family:Arial,Helvetica,sans-serif;padding:10px 20px 10px" align="left"> <p> Best regards, </p>
                                                                        <p> ' . $comOwner . '</p>
                                                                    </td> 
                                                                </tr>



                                                            </tbody> 
                                                        </table> 
                                                        <table style="background-color:#fff" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#fff"> 
                                                            <tbody> 
                                                                <tr> 
                                                                    <td style="padding:4px 20px;width:600px;line-height:12px">&nbsp;</td> 
                                                                </tr> 
                                                            </tbody> 
                                                            <tbody><tr> 
                                                                    <td style="padding:10px 0 7px;color:#9a9a9a;text-align:left;font-family:Arial,Helvetica,sans-serif;font-size:12px" align="left"> <p style="line-height:18px;margin:0;padding:0"> 
                                                                        </p><p style="line-height:24px;margin:0;padding:0">' . $comany_name . '</p>
                                                                        <p style="line-height:24px;margin:0;padding:0">Email : ' . $comEmail . ' </p> 
                                                                        <p style="line-height:24px;margin:0;padding:0">Tel: ' . $comConNumber . '</p> </td> 
                                                                </tr> 
                                                            </tbody></table> 
                                             


                                                    </td> 
                                                </tr> 
                                                <tr> 
                                                    <td style="padding:4px 20px;width:600px;line-height:12px">&nbsp;</td> 
                                                </tr> 
                                                <tr> 
                                                
                                                                            </tr> 
                                            </tbody> 
                                        </table> </td> 
                                </tr> 
                                <tr> 
                                    <td id="m_-1040695829873221998footer_content"> 
                                        <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#f6f8fb"> 
                                            <tbody>
                                                <tr> 
                                                    <td> 
                                                        <table style="padding:0" width="100%" cellspacing="0" cellpadding="0" border="0" align="center"> 
                                                            <tbody> 


                                                                <tr> 
                                                                    <td style="padding:0px 0 7px;color:#9a9a9a;text-align:left;font-family:Arial,Helvetica,sans-serif;font-size:12px" align="left"> <p style="line-height:18px;margin:0;padding:0">Website By : <a href="https://synotec.lk/">Synotec Holdings</a></p> </td> 
                                                                </tr> 
                                                                <tr></tr> 
                                                            </tbody> 
                                                        </table> </td> 
                                                </tr> 
                                            </tbody>
                                        </table> </td> 
                                </tr> 
                            </tbody>
                        </table> </td> 
                </tr> 
            </tbody>
        </table>



    </body>

</html>';
$company_message = '<html xmlns="http://www.w3.org/1999/xhtml">

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title>Synotec Email</title>

    </head>



    <body>

        <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#f6f8fb"> 
            <tbody>
                <tr> 
                    <td style="padding-top:10px;padding-bottom:30px;padding-left:16px;padding-right:16px" align="center"> 
                        <table style="width:602px" width="602" cellspacing="0" cellpadding="0" border="0" align="center"> 
                            <tbody>

                                <tr> 
                                    <td bgcolor=""> 
                                        <table width="642" cellspacing="0" cellpadding="0" border="0"> 
                                            <tbody> 

                                                <tr> 
                                                    <td style="border:1px solid #dcdee3;padding:20px;background-color:#fff;width:600px" width="600px" bgcolor="#ffffff" align="center"> 
                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0"> 
                                                            <tbody>
                                                                <tr><td>
                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">

                                                                            <tbody><tr>



                                                                                  

                                                                                    <td width="393">

                                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-bottom: 25px;">

                                                                                            <tbody><tr>

                                                                                                    <td valign="middle" height="46" align="right">

                                                                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0">

                                                                                                            <tbody><tr>

                                                                                                                    <td width="67%" align="right">

                                                                                                                        <font style="font-family:Verdana,Geneva,sans-serif;color:#68696a;font-size:18px">

                                                                                                                            <a href="' . $site_link . '" style="color:#68696a;text-decoration:none;" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://www.gallecabsandtours.com&amp;source=gmail&amp;ust=1574393192616000&amp;usg=AFQjCNGNM8_Z7ZMe7ndwFlJuHEP29nDd3Q">

                                                                                                                                <h4>' . $website_name . '</h4>

                                                                                                                            </a>

                                                                                                                        </font>

                                                                                                                    </td>

                                                                                                                    <td width="4%">&nbsp;</td>

                                                                                                                </tr>

                                                                                                            </tbody></table>

                                                                                                    </td>

                                                                                                </tr>

                                                                                 

                                                                                            </tbody></table>

                                                                                    </td>

                                                                                </tr>

                                                                            </tbody></table>
                                                                    </td>
                                                                </tr><tr> 
                                                                    <td style="font-size:20px;color:#33468f;line-height:28px;font-family:Arial,Helvetica,sans-serif;padding-bottom:20px;padding-top: 0px;font-weight: 600;" align="left"> ' . $visitor_subject . ' </td> 
                                                                </tr>
                                                            </tbody> 
                                                        </table> 

                                                        <table style="background-color:#f5f7fa" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F5F7FA"> 

                                                            <tbody> 
                                                                <tr> 
                                                                    <td style="font-size:14px;color:#333;line-height:18px;font-family:Arial,Helvetica,sans-serif;padding:15px 20px 10px;font-weight: 600;" align="left"> Hi , ' . $comOwner . ' </td> 
                                                                </tr> 
                                                            </tbody> 
                                                        </table> 
                                                        <table style="background-color:#f5f7fa" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F5F7FA"> 
                                                            <tbody> 
                                                                <tr> 
                                                                    <td style="word-wrap:break-word;font-size:14px;color:#333;line-height:18px;font-family:Arial,Helvetica,sans-serif;padding:10px 20px" align="left"> <p> You have a new inquiry from website.Kindly request your attention on this matter.The details of the inquiry are shown bellow</p></td> 
                                                                </tr> 




                                                            </tbody> 
                                                        </table> 




                                                    </td> 
                                                </tr> 
                                                <tr> 
                                                    <td style="padding:4px 20px;width:600px;line-height:12px">&nbsp;</td> 
                                                </tr> 
                                                <tr> 
                                                    <td style="padding:20px;border:1px solid #dcdee3;width:600px;background-color:#fff"> 
                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0"> 
                                                            <tbody> 
                                                                <tr> 
                                                                   <td style="font-size:15px;color:#333;line-height:18px;font-family:Arial,Helvetica,sans-serif;padding:0 0 8px;font-weight: 700;" align="left"> The Details :</td>
                                                                </tr> 
                                                            </tbody> 
                                                        </table> 
                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0"> 
                                                            <tbody> 
                                                                <tr> 
                                                                    <ul>

                                                                        <li>

                                                                            <font style="font-family:Verdana,Geneva,sans-serif;color:#68696a;font-size:14px">

                                                                                Name : ' . $visitor_name . '

                                                                            </font>

                                                                        </li>

                                                                        <li>

                                                                            <font style="font-family:Verdana,Geneva,sans-serif;color:#68696a;font-size:14px">

                                                                                Email : <a href="mailto:' . $visitor_email . '" rel="noreferrer" target="_blank">' . $visitor_email . '</a>

                                                                            </font>

                                                                        </li>
                                                                        
     <li>

                                                                            <font style="font-family:Verdana,Geneva,sans-serif;color:#68696a;font-size:14px">

                                                                                 Contact Number : ' . $visitor_phone . '
                                                                            </font>

                                             



                                                                    </ul>
                                                                </tr> 
                                                            </tbody> 
                                                        </table> 
                                                        <table width="100%" cellspacing="0" cellpadding="0" border="0"> 
                                                            <tbody> 
                                                           
                                                                
                                                                <tr> 
                                                                    <td style="font-size:14px;color:#333;line-height:18px;font-family:Arial,Helvetica,sans-serif;padding-bottom:8px" align="left"> ' . $message . '</td> 
                                                                </tr> 
                                                            </tbody> 
                                                        </table> </td> 
                                                </tr> 
                                            </tbody> 
                                        </table> </td> 
                                </tr> 
                                <tr> 
                                    <td id="m_-1040695829873221998footer_content"> 
                                        <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#f6f8fb"> 
                                            <tbody>
                                                <tr> 
                                                    <td> 
                                                        <table style="padding:0" width="100%" cellspacing="0" cellpadding="0" border="0" align="center"> 
                                                            <tbody> 


                                                                <tr> 
                                                                    <td style="padding:0px 0 7px;color:#9a9a9a;text-align:left;font-family:Arial,Helvetica,sans-serif;font-size:12px" align="left"> <p style="line-height:18px;margin:0;padding:0">Website By : <a href="https://synotec.lk/">Synotec Holdings</a></p> </td> 
                                                                </tr> 
                                                                <tr></tr> 
                                                            </tbody> 
                                                        </table> </td> 
                                                </tr> 
                                            </tbody>
                                        </table> </td> 
                                </tr> 
                            </tbody>
                        </table> </td> 
                </tr> 
            </tbody>
        </table>



    </body>

</html>';
?>